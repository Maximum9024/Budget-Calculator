--creating the database
create database myDatabase;

--using the database
use myDatabase;

--creating the table in the the database
create table Person(
ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
UserName varchar(50),
Password varchar(50),
Income varchar(50),
Tax   varchar(50),
waterLights varchar(50),
travelCost varchar(50),
cellPhone varchar(50),
Others varchar(50),
totalExpense varchar(50),
rentalAmounts varchar(50),
priceProperty varchar(50),
houseDeposit varchar(50),
interestRate varchar(50),
monthlyPay varchar(50),
houseCost varchar(50),
houseMonthly varchar(50),
modelName varchar(50),
carPurchase varchar(50),
carDeposit varchar(50),
carRate varchar(50),
Insurance varchar(50),
vehicleCost varchar(50)


);


/* commented statements

insert into Person(UserName,Password) values('Thembi','hash password');
delete from Person where UserName='Thembi';
select * from Person;
*/