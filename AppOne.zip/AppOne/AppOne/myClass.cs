﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

//importing the library
using BudLib.library;
using System.Threading;

namespace AppOne
{
    class myClass
    {
        // creating entities object
        myDatabaseEntities1 myEntity = new myDatabaseEntities1();
       
     

        //Login method
        public void Login(TextBox myUser, TextBox myPass)
        {
            try {
                if (myUser.Text != null && myUser.Text != "" && myPass.Text != null && myPass.Text != "")
                {
                    List<Person> objUsers = myEntity.People.ToList<Person>();
                    myClass obj2 = new myClass();

                    foreach (Person u in objUsers)
                    {
                        if (u.UserName.Equals(myUser.Text) && u.Password.Equals(hash(myPass.Text)))
                        {

                            MainWindow m = new MainWindow();
                            m.lbl_LoginID.Content = u.ID;
                            m.lbl_UserName.Content = u.UserName;
                            m.txtBoxIncome.Text = u.Income;
                            m.txtBoxTax.Text = u.Tax;
                            m.txtBoxGrocery.Text = u.Grocery;
                            m.txtBoxWLights.Text = u.waterLights;
                            m.txtBoxTCost.Text = u.travelCost;
                            m.txtBoxCell.Text = u.cellPhone;
                            m.txtBoxOthers.Text = u.Others;
                            m.txtBoxETotal.Text = u.totalExpense;
                            m.txtBoxRent.Text = u.rentalAmounts;
                            m.txtBoxPropPrice.Text = u.priceProperty;
                            m.txtBoxDeposit.Text = u.houseDeposit;
                            m.txtBoxRate.Text = u.interestRate;
                            m.txtBoxMonthly.Text = u.houseMonthly;
                            m.txtBoxPropCost.Text = u.houseCost;
                            m.txtBoxPropTotal.Text = u.monthlyPay;
                            m.txtBoxMake.Text = u.modelName;
                            m.txtBoxPrice.Text = u.carPurchase;
                            m.txtBoxRate1.Text = u.carRate;
                            m.txtBoxVTotal.Text = u.vehicleCost;

                            Thread.Sleep(1000);
                            m.ShowDialog();
                            //reading data from the database from the loginID

                        }
                        else
                        {
                            MessageBox.Show("user does not exist, please register or enter the correct user");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("please enter user");
                }

            }
            catch (Exception m)
            {
                MessageBox.Show(m.Message);
            }

        }

        //Register method
        public void Register(TextBox myUser, TextBox myPass)
        {
            try
            {
                if (myUser.Text != null && myUser.Text != "" && myPass.Text != "" && myPass.Text != null)
                {
                    Person user = new Person();
                    string hashPass = myPass.Text;

                    //hashing the password
                    user.UserName = myUser.Text.Trim();
                    user.Password = hash(myPass.Text.Trim()).Trim();


                    myEntity.People.Add(user);
                    myEntity.SaveChanges();
                    Thread.Sleep(1000);
                    MessageBox.Show("User registered!");
                }
                else MessageBox.Show("Please enter correct details");

            }catch(Exception m)
            {
                MessageBox.Show(m.Message);
            }
        }
        //Hashing the password  method
        public String hash(string Password)
        {
            byte[] passTohash = System.Text.Encoding.UTF8.GetBytes(Password);
            using(SHA1Managed sha1= new SHA1Managed())
            {
                var hash = sha1.ComputeHash(passTohash);
                return Convert.ToBase64String(hash);
            }
        }
        
        //method to store data in the database
       public void dataStore(int loginID,string Income,string Tax,string waterLights,string cellPhone,string Others, string totalExpense,
           string rentalAmounts,string priceProperty,string houseDeposit,string interestRate,string monthlyPay, string houseCost,string houseMonthly,
           string modelName, string carPurchase, string carDeposit, string carRate,string Insurance,string vehicleCost) {

            try
            {
                myDatabaseEntities1 UpdateEntity = new myDatabaseEntities1();
                Person data = UpdateEntity.People.FirstOrDefault(i => i.ID == loginID);
                data.Income = Income;
                data.Tax = Tax;
                data.waterLights = waterLights;
                data.cellPhone = cellPhone;
                data.Others = Others;
                data.totalExpense = totalExpense;
                data.rentalAmounts = rentalAmounts;
                data.priceProperty = priceProperty;
                data.houseDeposit = houseDeposit;
                data.interestRate = interestRate;
                data.monthlyPay = monthlyPay;
                data.modelName = modelName;
                data.carPurchase = carPurchase;
                data.carDeposit = carDeposit;
                data.carRate = carRate;
                data.Insurance = Insurance;
                data.vehicleCost = vehicleCost;

                UpdateEntity.SaveChanges();

                //multithreading
                Thread.Sleep(2000);

                MessageBox.Show(" changes saved.");
            } catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
          

        }
       
     
    }
    

    class Functionality
    {

        private double Total_Expense = 0, Total_Monthly_Cost = 0, HomeCost = 0, Rent_cost = 0, VehicleCost = 0;


        //Getter to return Total Expense
        public double getTotal_Expense() { return Total_Expense; }

        //Getter to return Total accomationcost
        public double getTotal_Monthly_Cost() { return Total_Monthly_Cost; }

        //Getter to return Total HomeCost
        public double getTotal_Home_Cost() { return HomeCost; }

        //Getter to return Total Vehicle Cost
        public double getVehicle_Cost() { return VehicleCost; }

        //Getter for rent value
        public double get_Rent(TextBox rent)
        {
            if (rent.Text != "")
                Rent_cost = Acommodation.Rent(double.Parse(rent.Text));
            else MessageBox.Show("Enter valid Rent amount");
            return Rent_cost;
        }


        //method to calcuate the total Expenditure
        public double GetTotal(TextBox txtGroceries, TextBox txtLights, TextBox txtTravel, TextBox txtCell, TextBox txtOthers)
        {

            //Validation
            if (txtGroceries.Text != "" && txtLights.Text != "" && txtOthers.Text != "" && txtTravel.Text != "" && txtCell.Text != "" && txtGroceries.Text != null && txtLights.Text != null && txtOthers.Text != null && txtTravel.Text != null && txtCell.Text != null)
            {
                try
                {


                    Total_Expense = Expenses.Month(double.Parse(txtGroceries.Text), double.Parse(txtLights.Text), double.Parse(txtTravel.Text), double.Parse(txtCell.Text), double.Parse(txtOthers.Text));

                }
                catch (Exception m)
                {
                    MessageBox.Show(m.Message);
                }


            }
            else
            {
                MessageBox.Show("invalid input, Please enter valid values");
            }


            return Total_Expense;

        }

        //method to call the Accommodation cost method
        public double getAcc_Cost(TextBox txtPrice, TextBox txtDeposit, TextBox txtRate, TextBox months)
        {

            if (txtPrice.Text != "" && txtDeposit.Text != "" && txtRate.Text != "" && months.Text != "" && txtPrice.Text != null && txtDeposit.Text != null && txtRate.Text != null && months.Text != null)
            {


                try
                {
                    Total_Monthly_Cost = Acommodation.HomeLoan(double.Parse(txtPrice.Text), double.Parse(txtDeposit.Text), double.Parse(txtRate.Text), double.Parse(months.Text));
                    HomeCost = Acommodation.getHomeCost();

                }
                catch (Exception m)
                {
                    MessageBox.Show(m.Message);
                }
            }
            else
            {
                MessageBox.Show("Please enter invalid inputs");
            }


            return Total_Monthly_Cost;

        }


        //Method to calculate the Vehicle Cost
        public double get_VehicleCost(TextBox txtPrice, TextBox txtDeposit, TextBox txtRate, TextBox premium)
        {
            try
            {
                //Validation
                if (txtPrice.Text != "" && txtDeposit.Text != "" && txtRate.Text != "" && premium.Text != "")
                {
                    VehicleCost = Vehicle.CalcVehiAmount(Double.Parse(txtPrice.Text), Double.Parse(txtDeposit.Text), Double.Parse(txtRate.Text), Double.Parse(premium.Text));

                }
                else
                {
                    MessageBox.Show("Please enter valid values on the fields");
                }
            }
            catch (Exception m)
            {
                MessageBox.Show(m.Message);
            }
            return VehicleCost;
        }
        public void Display_Results(RichTextBox Display, TextBox txtGross, TextBox txtTax, TextBox txtExpense, TextBox HouseCost, TextBox txtMonthly, TextBox txtVehicleCost)
        {

            try
            {
                Display.AppendText( "*********************\nGross Income R " + txtGross.Text + "\nTax R " + txtTax.Text + "\nTotal Expenditure R " + txtExpense.Text + "\nAcommodation \nHouse Cost R" + HouseCost.Text + " \nMonthly cost R " + txtMonthly.Text + " \nVehicle Cost R" + txtVehicleCost.Text);
                
                Display.AppendText("\n*********************");
                Display.AppendText("\nBalance R" + Balance(txtGross, txtTax, txtExpense, txtMonthly, txtVehicleCost));


                //SHowing loan approval
                MessageBox.Show(LoanAproval(txtGross, txtMonthly));
            }
            catch (Exception m)
            {
                MessageBox.Show(m.Message);
            }
        }
        //cakulates if the user gets a loan approval
        public String LoanAproval(TextBox txtGross, TextBox txtMonthly)
        {
            double Gross, Monthly;
            //storing values to variables
            Gross = double.Parse(txtGross.Text);


            Monthly = double.Parse(txtMonthly.Text);


            if (Monthly > Math.Round((Gross / 3), 2))
                return "House Monthly pay is more than 3rd gross, Loan cannot be Approved";
            else return "Loan Approved";
        }
        //Calulating the nce
        public double Balance(TextBox txtGross, TextBox txtTax, TextBox txtEpense, TextBox txtMonthly, TextBox txtVehicleCost)
        {
            double Balance = 0;
            Balance = double.Parse(txtGross.Text) - (double.Parse(txtTax.Text) + double.Parse(txtEpense.Text) + double.Parse(txtMonthly.Text) + double.Parse(txtVehicleCost.Text));




            return Balance;
        }
    }


}

