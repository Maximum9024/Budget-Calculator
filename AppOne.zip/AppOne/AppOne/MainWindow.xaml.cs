﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppOne
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Functionality obj = new Functionality();
      
        public MainWindow()
        {
            InitializeComponent();

           

        }

        private void btnTotal_Click(object sender, RoutedEventArgs e)
        {
            //calling the method to calculate the total expenditure
            obj.GetTotal(txtBoxGrocery, txtBoxWLights, txtBoxTCost, txtBoxCell, txtBoxOthers);
            
            //display total expense
            txtBoxETotal.Text = obj.getTotal_Expense().ToString();

        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
          

            //calculating the property cost
            if (rdoBtnBuy.IsChecked==true)
            {
                obj.getAcc_Cost(txtBoxPropPrice, txtBoxDeposit, txtBoxRate, txtBoxMonthly);
                txtBoxPropTotal.Text= obj.getTotal_Monthly_Cost().ToString();
                txtBoxPropCost.Text = obj.getTotal_Home_Cost().ToString();

                txtBoxRent.IsEnabled = false;
            }
            else
            {
                txtBoxRent.IsEnabled = true;
              

            }
            //calculating the rent cost
            if (rdoBtnRenting.IsChecked == true)
            {
                txtBoxPropTotal.Text = obj.get_Rent(txtBoxRent).ToString();
                txtBoxPropCost.Text = obj.getTotal_Monthly_Cost().ToString();
;
            }

        }

        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            ///calculating the vehivle cost
            obj.get_VehicleCost(txtBoxPrice, txtBoxVDeposit, txtBoxRate1, txtBoxInsure);
            txtBoxVTotal.Text = obj.getVehicle_Cost().ToString();
        }

        private void btnResults_Click(object sender, RoutedEventArgs e)
        {
            myClass obj2 = new myClass();
            //Viewing all the results
            obj.Display_Results(richTxtResults, txtBoxIncome, txtBoxTax, txtBoxETotal, txtBoxPropCost, txtBoxMonthly, txtBoxVTotal);

            //Storing data into the database
            obj2.dataStore(int.Parse(lbl_LoginID.Content.ToString()),txtBoxIncome.Text, txtBoxTax.Text, txtBoxWLights.Text, txtBoxCell.Text, txtBoxOthers.Text, txtBoxETotal.Text, txtBoxRent.Text, txtBoxPropPrice.Text, txtBoxDeposit.Text, txtBoxRate.Text, txtBoxMonthly.Text, txtBoxPropPrice.Text, txtBoxPropTotal.Text, txtBoxMake.Text, txtBoxPrice.Text, txtBoxVDeposit.Text, txtBoxRate1.Text, txtBoxInsure.Text, txtBoxVTotal.Text);
        }

        private void rdoBtnRenting_Checked(object sender, RoutedEventArgs e)
        {

            if (rdoBtnRenting.IsChecked == true)
            {
                txtBoxRent.IsEnabled = true;
                txtBoxPropPrice.IsEnabled = false;
                txtBoxDeposit.IsEnabled = false;
                txtBoxRate.IsEnabled = false;
                txtBoxMonthly.IsEnabled = false;
            }else
            {
                txtBoxRent.IsEnabled = false;
                txtBoxPropPrice.IsEnabled = true;
                txtBoxDeposit.IsEnabled = true;
                txtBoxRate.IsEnabled = true;
                txtBoxMonthly.IsEnabled = true;

            }

        }

        private void rdoBtnBuy_Checked(object sender, RoutedEventArgs e)
        {
            if (rdoBtnBuy.IsChecked == true)
            {
                txtBoxRent.IsEnabled = false;
                txtBoxRent.IsEnabled = true;
                txtBoxRent.IsEnabled = false;
                txtBoxPropPrice.IsEnabled = true;
                txtBoxDeposit.IsEnabled = true;
                txtBoxRate.IsEnabled = true;
                txtBoxMonthly.IsEnabled = true;

            }
            else
            {
                txtBoxRent.IsEnabled = true;
            }
           

        }
    }
}
