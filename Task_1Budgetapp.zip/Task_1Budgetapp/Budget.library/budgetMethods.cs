﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Budget.library
{
    public class budgetMethods
    {
    }
  public  abstract class Expenses
    {
       

        //Monthly Income
        double Income, Tax;
        //Expense variables
        
        //calculating monthly expenses
        public static  double Month(double Groceries, double Watlights, double Travel_costs, double cellPhone, double Others)
        {
            List<double> allExpense = new List<double>();
            allExpense.Add(Groceries);
            allExpense.Add(Watlights);
            allExpense.Add(Travel_costs);
            allExpense.Add(cellPhone);
            allExpense.Add(Others);


            return allExpense.Sum();
        }

        //Calculate Tax
        public double Net(double Income,double Tax)
        {
           
            return Income-Tax;
        }

    }

public    abstract class Acommodation
    {
        //calculating homeloan
         private static  double HomeCost = 0;
        //getter for HomeCost
        public static double getHomeCost() { return HomeCost; }

        public static double HomeLoan( double price,double deposit,double rate, int months)
        {
            double Loan = 0, Cost = 0, Monthly_Repayment = 0; ;
            rate = (rate / 100);
            price = price - deposit;
           
            Cost = price*(1+rate*(months/12));
            Monthly_Repayment = Cost / months;
            HomeCost = Cost;
            
            return Math.Round( Monthly_Repayment,2);
        }

        //calculating Rent amount
        public static double Rent(double Amount)
        {
            return Amount;
        }

    }
 public   abstract class Vehicle
    {
        //calculates the loan vehicle
        public static double CalcVehiAmount(double price,double deposit,double rate, double premium)
        {
            double Cost = 0,Monthly_Payment=0,Period=0;
            
            rate = (rate/100);
            price = price - deposit;
            //Period in 5 years
            Period = 5 ;
            Cost = price * (1 + (rate*Period));
            Monthly_Payment = Cost /(Period * 12);

            return  Math.Round(Monthly_Payment+premium,2);
        }

    }
}
