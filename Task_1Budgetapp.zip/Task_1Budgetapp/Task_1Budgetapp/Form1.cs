﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Budget.library;

namespace Task_1Budgetapp
{
   
    public partial class Form1 : Form
    {

        Functionality obj = new Functionality();

        public Form1()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void rdoRent_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void rdoBuy_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnCalcAccom_Click(object sender, EventArgs e)
        {
            //Calculating Accomodation cost
            if (rdoBuy.Checked == true)
            {
               obj.getAcc_Cost(txtProp, txtDeposit, txtInterest, txtRepay);
                txtMon_Pay.Text= obj.getTotal_Monthly_Cost().ToString();
                txtAccom_Cost.Text = obj.getTotal_Home_Cost().ToString();
            }

            if (rdoRent.Checked == true)
            {
                
                txtMon_Pay.Text = obj.get_Rent(txtRent).ToString();
                txtAccom_Cost.Text = obj.get_Rent(txtRent).ToString();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            //Calculating the Total Expenditure
            obj.GetTotal(txtGrocery, txtLights, txtCell, txtTravel, txtOthers);
            //Displays the total amount
            txtExp.Text =obj.getTotal_Expense().ToString();

            
        }

        private void btnVehicleCost_Click(object sender, EventArgs e)
        {
            //calculating the vehicle cost
            obj.get_VehicleCost(txtPrice, txtVehicleDeposit, txtVehicleRate, txtInsurance);
            txtVcost.Text = obj.getVehicle_Cost().ToString();
        }

        private void txtTax_TextChanged(object sender, EventArgs e)
        {

        }

       
        //Showing all the cost
        private void btnResults_Click(object sender, EventArgs e)
        {
            obj.Display_Results(txtDisplay, txtGrossIncome, txtTax, txtExp, txtAccom_Cost, txtMon_Pay, txtVcost);
        }
    }
}
