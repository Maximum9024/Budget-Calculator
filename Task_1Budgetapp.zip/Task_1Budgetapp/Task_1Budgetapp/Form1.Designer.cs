﻿namespace Task_1Budgetapp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtOthers = new System.Windows.Forms.TextBox();
            this.txtCell = new System.Windows.Forms.TextBox();
            this.txtTravel = new System.Windows.Forms.TextBox();
            this.txtLights = new System.Windows.Forms.TextBox();
            this.txtGrocery = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.grpRenting = new System.Windows.Forms.GroupBox();
            this.grpPropertyBuy = new System.Windows.Forms.GroupBox();
            this.btnCalcAccom = new System.Windows.Forms.Button();
            this.txtRepay = new System.Windows.Forms.TextBox();
            this.txtInterest = new System.Windows.Forms.TextBox();
            this.txtDeposit = new System.Windows.Forms.TextBox();
            this.txtProp = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtRent = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.rdoBuy = new System.Windows.Forms.RadioButton();
            this.rdoRent = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnVehicleCost = new System.Windows.Forms.Button();
            this.txtInsurance = new System.Windows.Forms.TextBox();
            this.txtVehicleRate = new System.Windows.Forms.TextBox();
            this.txtVehicleDeposit = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.txtGrossIncome = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.txtExp = new System.Windows.Forms.TextBox();
            this.txtDisplay = new System.Windows.Forms.RichTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtAccom_Cost = new System.Windows.Forms.TextBox();
            this.txtMon_Pay = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtVcost = new System.Windows.Forms.TextBox();
            this.btnResults = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpRenting.SuspendLayout();
            this.grpPropertyBuy.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(370, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Budget Calculator";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(60, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Gross monthly Income :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(380, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Monthly Tax deduction :";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtExp);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtOthers);
            this.groupBox1.Controls.Add(this.txtCell);
            this.groupBox1.Controls.Add(this.txtTravel);
            this.groupBox1.Controls.Add(this.txtLights);
            this.groupBox1.Controls.Add(this.txtGrocery);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBox1.Location = new System.Drawing.Point(55, 179);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(256, 451);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Monthly Expenditures";
            // 
            // txtOthers
            // 
            this.txtOthers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOthers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOthers.Location = new System.Drawing.Point(141, 217);
            this.txtOthers.Name = "txtOthers";
            this.txtOthers.Size = new System.Drawing.Size(100, 15);
            this.txtOthers.TabIndex = 18;
            // 
            // txtCell
            // 
            this.txtCell.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCell.Location = new System.Drawing.Point(141, 179);
            this.txtCell.Name = "txtCell";
            this.txtCell.Size = new System.Drawing.Size(100, 15);
            this.txtCell.TabIndex = 17;
            this.txtCell.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txtTravel
            // 
            this.txtTravel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTravel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTravel.Location = new System.Drawing.Point(141, 136);
            this.txtTravel.Name = "txtTravel";
            this.txtTravel.Size = new System.Drawing.Size(100, 15);
            this.txtTravel.TabIndex = 16;
            // 
            // txtLights
            // 
            this.txtLights.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLights.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLights.Location = new System.Drawing.Point(141, 88);
            this.txtLights.Name = "txtLights";
            this.txtLights.Size = new System.Drawing.Size(100, 15);
            this.txtLights.TabIndex = 15;
            // 
            // txtGrocery
            // 
            this.txtGrocery.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGrocery.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGrocery.Location = new System.Drawing.Point(141, 44);
            this.txtGrocery.Name = "txtGrocery";
            this.txtGrocery.Size = new System.Drawing.Size(100, 15);
            this.txtGrocery.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(17, 224);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 18);
            this.label8.TabIndex = 13;
            this.label8.Text = "Others :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 186);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 18);
            this.label7.TabIndex = 12;
            this.label7.Text = "Cellphone :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 18);
            this.label6.TabIndex = 11;
            this.label6.Text = "Travel costs :";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 18);
            this.label5.TabIndex = 10;
            this.label5.Text = "Water + lights :";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Groceries :";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMon_Pay);
            this.groupBox2.Controls.Add(this.txtAccom_Cost);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.btnCalcAccom);
            this.groupBox2.Controls.Add(this.grpPropertyBuy);
            this.groupBox2.Controls.Add(this.grpRenting);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.rdoBuy);
            this.groupBox2.Controls.Add(this.rdoRent);
            this.groupBox2.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBox2.Location = new System.Drawing.Point(329, 179);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(320, 441);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Accomodation";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // grpRenting
            // 
            this.grpRenting.Controls.Add(this.txtRent);
            this.grpRenting.Controls.Add(this.label10);
            this.grpRenting.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRenting.ForeColor = System.Drawing.Color.DarkRed;
            this.grpRenting.Location = new System.Drawing.Point(10, 57);
            this.grpRenting.Name = "grpRenting";
            this.grpRenting.Size = new System.Drawing.Size(289, 74);
            this.grpRenting.TabIndex = 3;
            this.grpRenting.TabStop = false;
            this.grpRenting.Text = "Renting";
            // 
            // grpPropertyBuy
            // 
            this.grpPropertyBuy.Controls.Add(this.txtRepay);
            this.grpPropertyBuy.Controls.Add(this.txtInterest);
            this.grpPropertyBuy.Controls.Add(this.txtDeposit);
            this.grpPropertyBuy.Controls.Add(this.txtProp);
            this.grpPropertyBuy.Controls.Add(this.label14);
            this.grpPropertyBuy.Controls.Add(this.label13);
            this.grpPropertyBuy.Controls.Add(this.label12);
            this.grpPropertyBuy.Controls.Add(this.label11);
            this.grpPropertyBuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpPropertyBuy.ForeColor = System.Drawing.Color.DarkRed;
            this.grpPropertyBuy.Location = new System.Drawing.Point(10, 137);
            this.grpPropertyBuy.Name = "grpPropertyBuy";
            this.grpPropertyBuy.Size = new System.Drawing.Size(289, 175);
            this.grpPropertyBuy.TabIndex = 4;
            this.grpPropertyBuy.TabStop = false;
            this.grpPropertyBuy.Text = "Buying Property";
            // 
            // btnCalcAccom
            // 
            this.btnCalcAccom.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnCalcAccom.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.btnCalcAccom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcAccom.ForeColor = System.Drawing.Color.DarkRed;
            this.btnCalcAccom.Location = new System.Drawing.Point(10, 318);
            this.btnCalcAccom.Name = "btnCalcAccom";
            this.btnCalcAccom.Size = new System.Drawing.Size(116, 38);
            this.btnCalcAccom.TabIndex = 19;
            this.btnCalcAccom.Text = "Calculate";
            this.btnCalcAccom.UseVisualStyleBackColor = false;
            this.btnCalcAccom.Click += new System.EventHandler(this.btnCalcAccom_Click);
            // 
            // txtRepay
            // 
            this.txtRepay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRepay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRepay.Location = new System.Drawing.Point(170, 131);
            this.txtRepay.Name = "txtRepay";
            this.txtRepay.Size = new System.Drawing.Size(100, 15);
            this.txtRepay.TabIndex = 18;
            // 
            // txtInterest
            // 
            this.txtInterest.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInterest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInterest.Location = new System.Drawing.Point(170, 95);
            this.txtInterest.Name = "txtInterest";
            this.txtInterest.Size = new System.Drawing.Size(100, 15);
            this.txtInterest.TabIndex = 17;
            // 
            // txtDeposit
            // 
            this.txtDeposit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDeposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeposit.Location = new System.Drawing.Point(170, 61);
            this.txtDeposit.Name = "txtDeposit";
            this.txtDeposit.Size = new System.Drawing.Size(100, 15);
            this.txtDeposit.TabIndex = 16;
            // 
            // txtProp
            // 
            this.txtProp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProp.Location = new System.Drawing.Point(170, 32);
            this.txtProp.Name = "txtProp";
            this.txtProp.Size = new System.Drawing.Size(100, 15);
            this.txtProp.TabIndex = 15;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(7, 134);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(180, 18);
            this.label14.TabIndex = 3;
            this.label14.Text = " Months repay (240-360)  :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 102);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 18);
            this.label13.TabIndex = 2;
            this.label13.Text = "Interest rate (%) :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 18);
            this.label12.TabIndex = 1;
            this.label12.Text = "Total deposit :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 18);
            this.label11.TabIndex = 0;
            this.label11.Text = "Price of Property :";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // txtRent
            // 
            this.txtRent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRent.Location = new System.Drawing.Point(129, 31);
            this.txtRent.Name = "txtRent";
            this.txtRent.Size = new System.Drawing.Size(100, 15);
            this.txtRent.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 35);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 18);
            this.label10.TabIndex = 0;
            this.label10.Text = "Rental Amount :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 15);
            this.label9.TabIndex = 2;
            this.label9.Text = "Type :";
            // 
            // rdoBuy
            // 
            this.rdoBuy.AutoSize = true;
            this.rdoBuy.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoBuy.Location = new System.Drawing.Point(131, 34);
            this.rdoBuy.Name = "rdoBuy";
            this.rdoBuy.Size = new System.Drawing.Size(64, 19);
            this.rdoBuy.TabIndex = 1;
            this.rdoBuy.TabStop = true;
            this.rdoBuy.Text = "Buying";
            this.rdoBuy.UseVisualStyleBackColor = true;
            this.rdoBuy.CheckedChanged += new System.EventHandler(this.rdoBuy_CheckedChanged);
            // 
            // rdoRent
            // 
            this.rdoRent.AutoSize = true;
            this.rdoRent.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoRent.Location = new System.Drawing.Point(56, 34);
            this.rdoRent.Name = "rdoRent";
            this.rdoRent.Size = new System.Drawing.Size(67, 19);
            this.rdoRent.TabIndex = 0;
            this.rdoRent.TabStop = true;
            this.rdoRent.Text = "Renting";
            this.rdoRent.UseVisualStyleBackColor = true;
            this.rdoRent.CheckedChanged += new System.EventHandler(this.rdoRent_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtVcost);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.btnVehicleCost);
            this.groupBox4.Controls.Add(this.txtInsurance);
            this.groupBox4.Controls.Add(this.txtVehicleRate);
            this.groupBox4.Controls.Add(this.txtVehicleDeposit);
            this.groupBox4.Controls.Add(this.txtPrice);
            this.groupBox4.Controls.Add(this.txtModel);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBox4.Location = new System.Drawing.Point(655, 179);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 244);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vehicle";
            // 
            // btnVehicleCost
            // 
            this.btnVehicleCost.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnVehicleCost.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.btnVehicleCost.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVehicleCost.Location = new System.Drawing.Point(10, 188);
            this.btnVehicleCost.Name = "btnVehicleCost";
            this.btnVehicleCost.Size = new System.Drawing.Size(116, 38);
            this.btnVehicleCost.TabIndex = 20;
            this.btnVehicleCost.Text = "Calculate";
            this.btnVehicleCost.UseVisualStyleBackColor = false;
            this.btnVehicleCost.Click += new System.EventHandler(this.btnVehicleCost_Click);
            // 
            // txtInsurance
            // 
            this.txtInsurance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInsurance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInsurance.Location = new System.Drawing.Point(169, 156);
            this.txtInsurance.Name = "txtInsurance";
            this.txtInsurance.Size = new System.Drawing.Size(100, 15);
            this.txtInsurance.TabIndex = 19;
            // 
            // txtVehicleRate
            // 
            this.txtVehicleRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVehicleRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVehicleRate.Location = new System.Drawing.Point(169, 118);
            this.txtVehicleRate.Name = "txtVehicleRate";
            this.txtVehicleRate.Size = new System.Drawing.Size(100, 15);
            this.txtVehicleRate.TabIndex = 18;
            // 
            // txtVehicleDeposit
            // 
            this.txtVehicleDeposit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVehicleDeposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVehicleDeposit.Location = new System.Drawing.Point(169, 92);
            this.txtVehicleDeposit.Name = "txtVehicleDeposit";
            this.txtVehicleDeposit.Size = new System.Drawing.Size(100, 15);
            this.txtVehicleDeposit.TabIndex = 17;
            // 
            // txtPrice
            // 
            this.txtPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.Location = new System.Drawing.Point(169, 63);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(100, 15);
            this.txtPrice.TabIndex = 16;
            // 
            // txtModel
            // 
            this.txtModel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModel.Location = new System.Drawing.Point(169, 32);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(100, 15);
            this.txtModel.TabIndex = 15;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 159);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(148, 18);
            this.label19.TabIndex = 4;
            this.label19.Text = "Insurance premium : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 125);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(120, 18);
            this.label18.TabIndex = 3;
            this.label18.Text = "Interest rate (%) :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 92);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 18);
            this.label17.TabIndex = 2;
            this.label17.Text = "Total deposit :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(7, 65);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(111, 18);
            this.label16.TabIndex = 1;
            this.label16.Text = "Purchase price :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 35);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(126, 18);
            this.label15.TabIndex = 0;
            this.label15.Text = "Model and Make :";
            // 
            // txtTax
            // 
            this.txtTax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTax.Location = new System.Drawing.Point(587, 136);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(100, 13);
            this.txtTax.TabIndex = 6;
            this.txtTax.TextChanged += new System.EventHandler(this.txtTax_TextChanged);
            // 
            // txtGrossIncome
            // 
            this.txtGrossIncome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGrossIncome.Location = new System.Drawing.Point(260, 139);
            this.txtGrossIncome.Name = "txtGrossIncome";
            this.txtGrossIncome.Size = new System.Drawing.Size(100, 13);
            this.txtGrossIncome.TabIndex = 7;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(16, 326);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 20);
            this.label20.TabIndex = 19;
            this.label20.Text = "Total  R:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LavenderBlush;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(67, 273);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 31);
            this.button2.TabIndex = 21;
            this.button2.Text = "Get Total";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtExp
            // 
            this.txtExp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtExp.Enabled = false;
            this.txtExp.Location = new System.Drawing.Point(141, 323);
            this.txtExp.Name = "txtExp";
            this.txtExp.Size = new System.Drawing.Size(100, 19);
            this.txtExp.TabIndex = 22;
            // 
            // txtDisplay
            // 
            this.txtDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDisplay.Location = new System.Drawing.Point(655, 471);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(316, 169);
            this.txtDisplay.TabIndex = 8;
            this.txtDisplay.Text = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(10, 368);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 16);
            this.label21.TabIndex = 20;
            this.label21.Text = "Cost  R:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(10, 399);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(122, 16);
            this.label22.TabIndex = 21;
            this.label22.Text = "Monthly Pay R:";
            // 
            // txtAccom_Cost
            // 
            this.txtAccom_Cost.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAccom_Cost.Enabled = false;
            this.txtAccom_Cost.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccom_Cost.Location = new System.Drawing.Point(180, 365);
            this.txtAccom_Cost.Name = "txtAccom_Cost";
            this.txtAccom_Cost.Size = new System.Drawing.Size(100, 16);
            this.txtAccom_Cost.TabIndex = 22;
            // 
            // txtMon_Pay
            // 
            this.txtMon_Pay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMon_Pay.Enabled = false;
            this.txtMon_Pay.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMon_Pay.Location = new System.Drawing.Point(180, 394);
            this.txtMon_Pay.Name = "txtMon_Pay";
            this.txtMon_Pay.Size = new System.Drawing.Size(100, 16);
            this.txtMon_Pay.TabIndex = 23;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(132, 202);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(58, 16);
            this.label23.TabIndex = 21;
            this.label23.Text = "Cost R:";
            // 
            // txtVcost
            // 
            this.txtVcost.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVcost.Enabled = false;
            this.txtVcost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVcost.Location = new System.Drawing.Point(197, 199);
            this.txtVcost.Name = "txtVcost";
            this.txtVcost.Size = new System.Drawing.Size(72, 15);
            this.txtVcost.TabIndex = 22;
            // 
            // btnResults
            // 
            this.btnResults.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnResults.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResults.Location = new System.Drawing.Point(715, 430);
            this.btnResults.Name = "btnResults";
            this.btnResults.Size = new System.Drawing.Size(153, 35);
            this.btnResults.TabIndex = 9;
            this.btnResults.Text = "Results";
            this.btnResults.UseVisualStyleBackColor = false;
            this.btnResults.Click += new System.EventHandler(this.btnResults_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.HotPink;
            this.ClientSize = new System.Drawing.Size(1035, 698);
            this.Controls.Add(this.btnResults);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.txtGrossIncome);
            this.Controls.Add(this.txtTax);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.DarkRed;
            this.Name = "Form1";
            this.Text = "Budget Plan";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpRenting.ResumeLayout(false);
            this.grpRenting.PerformLayout();
            this.grpPropertyBuy.ResumeLayout(false);
            this.grpPropertyBuy.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox grpRenting;
        private System.Windows.Forms.GroupBox grpPropertyBuy;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rdoBuy;
        private System.Windows.Forms.RadioButton rdoRent;
        private System.Windows.Forms.TextBox txtOthers;
        private System.Windows.Forms.TextBox txtCell;
        private System.Windows.Forms.TextBox txtTravel;
        private System.Windows.Forms.TextBox txtLights;
        private System.Windows.Forms.TextBox txtGrocery;
        private System.Windows.Forms.TextBox txtRent;
        private System.Windows.Forms.TextBox txtRepay;
        private System.Windows.Forms.TextBox txtInterest;
        private System.Windows.Forms.TextBox txtDeposit;
        private System.Windows.Forms.TextBox txtProp;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtInsurance;
        private System.Windows.Forms.TextBox txtVehicleRate;
        private System.Windows.Forms.TextBox txtVehicleDeposit;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnCalcAccom;
        private System.Windows.Forms.Button btnVehicleCost;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.TextBox txtGrossIncome;
        private System.Windows.Forms.TextBox txtExp;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RichTextBox txtDisplay;
        private System.Windows.Forms.TextBox txtMon_Pay;
        private System.Windows.Forms.TextBox txtAccom_Cost;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtVcost;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnResults;
    }
}

